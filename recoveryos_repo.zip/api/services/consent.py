def can_send_weekly(consent: bool) -> bool:
    return bool(consent)
