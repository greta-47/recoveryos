def retrieve(query:str)->list:
    return []
