# RecoveryOS

AI-powered relapse prevention platform. Starter repo for Devin/agents to execute.

## Quick Start (DEV)
```bash
cp .env.example .env
docker compose -f ops/docker-compose.yml up --build
# API at http://localhost:8000/docs
```
